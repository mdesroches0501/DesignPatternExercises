public class CourseView
{
  public void printCourseDetails(String courseName, String courseNumber, String courseDescription)
  {
    System.out.println("Course: " + courseName);
    System.out.println("Number: " + courseNumber);
    System.out.println("Description: " + courseDescription);
  }
}