public class NVBonusSlot extends Slot {
    public NVBonusSlot() {
        name = "Nevada Bonus style ";
        cabinet = "Small cabinet ";
        display = "CRT ";
        payment = "Ticket in, ticket out ";
        GPU = "X86";
        OS = "Linux ";
    }
}