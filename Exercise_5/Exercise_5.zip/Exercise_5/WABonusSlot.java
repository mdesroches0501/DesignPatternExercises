public class WABonusSlot extends Slot {
    public WABonusSlot() {
        name = "Washington Bonus Slot style ";
        cabinet = "Medium cabinet ";
        display = "VGA ";
        payment = "Ticket in, ticket out ";
        GPU = "ARM";
        OS = "Symbian ";
    }
}