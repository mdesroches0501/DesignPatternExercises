public class NJBonusSlot extends Slot {
    public NJBonusSlot() {
        name = "New Jersey Bonus style ";
        cabinet = "Large cabinet ";
        display = "Reels ";
        payment = "Coins ";
        GPU = "ARM";
        OS = "Windows ME ";
    }
}