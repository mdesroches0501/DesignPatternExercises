public class NJStraightSlot extends Slot {
    public NJStraightSlot() {
        name = "New Jersey Straight style ";
        cabinet = "Small cabinet ";
        display = "LCD ";
        payment = "Coins ";
        GPU = "ARM";
        OS = "Windows ME ";
    }
}