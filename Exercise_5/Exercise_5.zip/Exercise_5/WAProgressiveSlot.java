public class WAProgressiveSlot extends Slot {
    public WAProgressiveSlot() {
        name = "Washington Progressive Slot style ";
        cabinet = "Large cabinet ";
        display = "Reels ";
        payment = "coins ";
        GPU = "ARM";
        OS = "Android ";
    }
}