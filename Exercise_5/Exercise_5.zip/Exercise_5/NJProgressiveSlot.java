public class NJProgressiveSlot extends Slot {
    public NJProgressiveSlot() {
        name = "New Jersey Progressive style ";
        cabinet = "Small cabinet ";
        display = "CRT ";
        payment = "Bills ";
        GPU = "X86";
        OS = "Windows XP ";
    }
}