public class NVStraightSlot extends Slot {
    public NVStraightSlot() {
        name = "Nevada Straight style ";
        cabinet = "Large cabinet ";
        display = "Reels ";
        payment = "Ticket in, ticket out ";
        GPU = "ARM";
        OS = "Linux ";
    }
}