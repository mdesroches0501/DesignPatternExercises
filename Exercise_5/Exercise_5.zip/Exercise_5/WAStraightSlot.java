public class WAStraightSlot extends Slot {
    public WAStraightSlot() {
        name = "Washington Straight Slot style ";
        cabinet = "Large cabinet ";
        display = "Reels ";
        payment = "bills ";
        GPU = "ARM";
        OS = "Linux ";
    }
}