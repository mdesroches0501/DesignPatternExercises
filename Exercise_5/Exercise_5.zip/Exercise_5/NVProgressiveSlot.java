public class NVProgressiveSlot extends Slot {
    public NVProgressiveSlot() {
        name = "Nevada Progressive ";
        cabinet = "Medium cabinet ";
        display = "LCD ";
        payment = "Ticket in, ticket out ";
        GPU = "X77";
        OS = "Android ";
    }
}