public class Guitar implements GuitarController {

    public void pressFretButton(color button) {
        System.out.println("Pressing " + button.name);
    }

    public void pressPick() {
        System.out.println("Pick pressed");
    }

    public void pressTremelo {
        System.out.println("Bwop bwop wop wop")
    }
}